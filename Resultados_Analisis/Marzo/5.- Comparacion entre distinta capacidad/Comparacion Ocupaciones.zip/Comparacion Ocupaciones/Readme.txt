Matriz1 es : marzo con capacidad de la fila 1
